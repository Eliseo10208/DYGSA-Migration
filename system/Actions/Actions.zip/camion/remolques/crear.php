<?php
	include_once($_SERVER['DOCUMENT_ROOT'].'/init.php');
	
	if(!isset($_POST)) die;

	$nro_certificado = $_POST['nro_certificado'];
	$fecha_certificador = $_POST['fecha_certificador'];
	$nombre_transportista = $_POST['nombre_transportista'];
	$placa_rodaje = $_POST['placa_rodaje'];
	$marca = $_POST['marca'];
	$configuracion = $_POST['configuracion'];
	$capacidad_m3 = $_POST['capacidad_m3'];
	$capacidad_tn = $_POST['capacidad_tn'];
	$fecha_proxima_inscripcion = $_POST['fecha_proxima_inscripcion'];
	$costo_proxima_inscripcion = $_POST['costo_proxima_inscripcion'];
	$nro_ejes = $_POST['nro_ejes'];

	$files = array('pdf_habilitacion_vehicular' => array('name' => 'habilitacion_vehicular', 'status' => false), 
					'pdf_revision_tecnica' => array('name' => 'revision_tecnica', 'status' => false));

	$folder = time();
	$path = FileRemolques.'/'.$folder.'/';
	if (!file_exists($path)) {
	    mkdir($path, 0777, true);
	}

	foreach ($files as $key => $value) {
		if(isset($_FILES[$key]))
		{
			$ext = explode("/", $_FILES[$key]['type'])[1];
			$file_content = file_get_contents($_FILES[$key]['tmp_name']);
	 		$file_dump = file_put_contents($path.$value["name"].'.'.$ext, $file_content);

	 		$files[$key]["status"] = true;
		}
	}

	$sql->query("INSERT INTO `vehiculos_remolques` SET `folder` = '".$folder."', `nro_documento` = '".$nro_certificado."', `nombre` = '".$nombre_transportista."', `placa` = '".$placa_rodaje."', `marca` = '".$marca."', `configuracion` = '".$configuracion."', `cap_m3` = '".$capacidad_m3."', `cap_tn` = '".$capacidad_tn."', `fecha_ven_cert_hab_veh` = '".$fecha_certificador."', `fecha_prue_rev_tec_veh` = '".$fecha_proxima_inscripcion."', `costo_prue_rev_tec_veh` = '".$costo_proxima_inscripcion."', `pdf_habilitacion_vehicular` = '".$files["pdf_habilitacion_vehicular"]["status"]."', `pdf_revision_tecnica` = '".$files["pdf_revision_tecnica"]["status"]."', `nro_ejes` = '".$nro_ejes."'");

	$id = $sql->insert_id;
	if($id > 0)
	{
		echo json_encode(array('status' => 'success', 'id' => $id));
	}
	else
	{
		echo json_encode(array('status' => 'error'));
	}

?>