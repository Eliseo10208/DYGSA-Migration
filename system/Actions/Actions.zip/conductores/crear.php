<?php
	include_once($_SERVER['DOCUMENT_ROOT'].'/init.php');
	
	$tipo_doc = $_POST['tipo_doc'];
	$doc = $_POST['doc'];
	$nombre = $_POST['nombre'];
	$nacionalidad = $_POST['nacionalidad'];
	$fecha_nacimiento = $_POST['fecha_nacimiento'];
	$lugar_nacimiento = $_POST['lugar_nacimiento'];
	$estado_civil = $_POST['estado_civil'];
	$sexo = $_POST['sexo'];
	$direccion = $_POST['direccion'];
	$celular = $_POST['celular'];
	$celular2 = $_POST['celular2'];
	$email = $_POST['email'];
	$banco = $_POST['banco'];
	$nro_cuenta = $_POST['nro_cuenta'];
	$folio_licencia = $_POST['folio_licencia'];
	$categoria = $_POST['categoria'];
	$persona_contacto = $_POST['persona_contacto'];
	$telefono_contacto = $_POST['telefono_contacto'];
	$fecha_venc_safedriving = $_POST['fecha_venc_safedriving'];
	$fecha_exam_medico = $_POST['fecha_exam_medico'];
	$fecha_charla_empresa1 = $_POST['fecha_charla_empresa1'];
	$fecha_charla_empresa2 = $_POST['fecha_charla_empresa2'];
	$cargo = "conductor";
	$folder = time();

	$files = array('file_document' => array('name' => 'documento', 'status' => false), 
					'file_licencia' => array('name' => 'licencia', 'status' => false), 
					'file_r_control' => array('name' => 'r_control', 'status' => false), 
					'file_file_safedriving' => array('name' => 'safedriving', 'status' => false), 
					'file_examen_medico' => array('name' => 'examen_medico', 'status' => false));


	
	$path = FileEmpleados.'/'.$folder.'/';
	if (!file_exists($path)) {
	    mkdir($path, 0777, true);
	}

	foreach ($files as $key => $value) {
		if(isset($_FILES[$key]))
		{
			$ext = explode("/", $_FILES[$key]['type'])[1];
			$file_content = file_get_contents($_FILES[$key]['tmp_name']);
	 		$file_dump = file_put_contents($path.$value["name"].'.'.$ext, $file_content);

	 		$files[$key]["status"] = true;
		}
	}

	$ca = $sql->query("INSERT INTO `empleados` SET `folder` = '".$folder."', `tipo_empleado` = '".$cargo."', `tipo_doc` = '".$tipo_doc."', `doc` = '".$doc."', 
													`nombre` = '".$nombre."', 
													`nacionalidad` = '".$nacionalidad."', 
													`fecha_nacimiento` = '".$fecha_nacimiento."', 
													`lugar_nacimiento` = '".$lugar_nacimiento."', 
													`estado_civil` = '".$estado_civil."', 
													`sexo` = '".$sexo."',
													`direccion` = '".$direccion."', 
													`celular` = '".$celular."', 
													`celular2` = '".$celular2."', 
													`email` = '".$email."', 
													`banco` = '".$banco."', 
													`nro_cuenta` = '".$nro_cuenta."', 
													`folio_licencia` = '".$folio_licencia."', 
													`categoria` = '".$categoria."', 
													`persona_contacto` = '".$persona_contacto."', 
													`telefono_contacto` = '".$telefono_contacto."', 
													`fecha_venc_safedriving` = '".$fecha_venc_safedriving."', 
													`fecha_exam_medico` = '".$fecha_exam_medico."', 
													`fecha_charla_empresa1` = '".$fecha_charla_empresa1."', 
													`fecha_charla_empresa2` = '".$fecha_charla_empresa2."', 
													`file_document` = '".$files["file_document"]["status"]."',
													`file_file_safedriving` = '".$files["file_file_safedriving"]["status"]."',
													`file_licencia` = '".$files["file_licencia"]["status"]."',
													`file_r_control` = '".$files["file_r_control"]["status"]."',
													`file_examen_medico` = '".$files["file_examen_medico"]["status"]."'
													");

	$id = $sql->insert_id;
	if($ca == true)
	{
		echo json_encode(array('status' => 'success', 'id' => $id));
	}
	else
	{
		echo json_encode(array('status' => 'error'));
	}
?>